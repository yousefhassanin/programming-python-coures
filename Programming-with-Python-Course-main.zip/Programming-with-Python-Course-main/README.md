# Programming-with-Python-Course
This repository including the code files for programming with python course.
Course Outhines:
-Python Programming Language 
-PyQt Library
-SQL and Database
